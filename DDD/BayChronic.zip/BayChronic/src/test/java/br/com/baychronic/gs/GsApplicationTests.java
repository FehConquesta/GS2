package br.com.baychronic.gs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GsApplicationTests {

	@Test
	void contextLoads() {
	}

}
